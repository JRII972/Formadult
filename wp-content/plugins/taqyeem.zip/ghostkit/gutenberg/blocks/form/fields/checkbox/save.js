/**
 * WordPress dependencies
 */
const { Component } = wp.element;

/**
 * Block Save Class.
 */
class BlockSave extends Component {
  render() {
    return null;
  }
}

export default BlockSave;
